import os

gb_dir = "C:/Users/diego/Downloads/datalab/MemGbTest/gb_csv/"
mb_dir = "C:/Users/diego/Downloads/datalab/MemGbTest/mb_csv/"
dir = "C:/Users/diego/Downloads/datalab/MemGbTest/orig_csv/"

for filename in os.listdir(dir):
    fl = open(os.path.join(dir, filename),"r")
    gbfl = open(os.path.join(gb_dir, filename),"w+")
    mbfl = open(os.path.join(mb_dir, filename),"w+")
    for line in fl:
        spt = line.split(";")
        if(len(spt) == 3):
            gbfl.write(spt[0] + ";" + '{0:.1f}'.format(float(spt[1])/(1024**3)) + ";" + spt[2])
            mbfl.write(spt[0] + ";" + '{0:.1f}'.format(float(spt[1])/(1024**2)) + ";" + spt[2])
        else:
            gbfl.write(line)
            mbfl.write(line)
    fl.close()
    gbfl.close()
    mbfl.close()